#4.  Can you create a identity matrix of shape (3,4).
#  If yes write code for it.

import numpy as np

m = np.eye(3,4) #eye is used for identity matrix
print (f"The identity matrix of shape (3,4) is \n {m}")