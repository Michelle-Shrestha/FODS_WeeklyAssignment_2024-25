#1.Create a null vector of size 10 but the fifth value which is 1.

import numpy as np 

null_vector = np.zeros(10)#creating zero vector of size 10

null_vector[4]=1 #changin the 5th value (index 4) to 1
print(null_vector)