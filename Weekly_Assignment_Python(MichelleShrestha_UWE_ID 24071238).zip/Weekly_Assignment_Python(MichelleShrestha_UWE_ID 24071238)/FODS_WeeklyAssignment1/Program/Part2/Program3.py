#3. Write a program that will convert Celsius value to Fahrenheit.

C = int (input ("Enter the Celsius : "))
f = C * (9/5) +32
print ("Converting Celsius degree into Fahrenheit : ", f)